function [Im_E] = SmthEdge(Img)
% Detect Edges and Smooth them
% Here we use a canny edge detector for efficiency

% Edge Detector
Im_E = edge(rgb2gray(Img), 'canny'); %, 0.1

% Get a diffused edge map
smth_kernel = fspecial('average', 5);
Im_E = filter2(smth_kernel, Im_E);

end