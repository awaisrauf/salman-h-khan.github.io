function [H_SP_new] = holeSP(rDmap, seg_img)
% Select SP's whose majority of the portion lies in regions with holes

H_SP = unique(seg_img(~logical(rDmap)));
seg_img_A = zeros(480,640);
seg_img_B = zeros(480,640);
% The one with correct depth
seg_img_A(logical(rDmap)) = seg_img(logical(rDmap));
% The one with inpainted depth
seg_img_B(~logical(rDmap)) = seg_img(~logical(rDmap));

% 0.047 sec
H_SP_new = [];
parfor jj = 1:length(H_SP)
    if H_SP(jj) ~= 0
        if sum(sum(seg_img_B == H_SP(jj))) >= sum(sum(seg_img_A == H_SP(jj)))
            H_SP_new = [H_SP_new; H_SP(jj)];
        end
    end
end

end