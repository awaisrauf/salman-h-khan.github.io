function [Al] = adjMat(seg_img)
% Find the Adjacency Matrix for all SP
% Arrange the Adjacency matrix SP into order of decreasing adjacency

Num_SP = max(seg_img(:));
seg_img_temp = seg_img;
seg_img_temp(seg_img == 0) = Num_SP + 1;
[Am, Al] = regionadjacency(seg_img_temp, 8); % connectivity of 8

Am = Am(1:size(Am,1)-1, 1:size(Am,2)-1);
Al = Al(1:Num_SP, 1);
% Remove Num_SP+1 elements inside the Al cell array
Al = cellfun(@(x) x(1,1:(size(x,2) - ismember(Num_SP+1,x))), ...
    Al, 'UniformOutput', 0);

end

