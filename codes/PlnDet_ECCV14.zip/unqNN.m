function [seg_img2] = unqNN(H_SP_new, Al, Im_E, seg_img)
% Find all unique neighbours of incorrect planes

thresh = 25; thresh2 = 0.01;

H_SP_NN = Al(H_SP_new,1);
H_SP_NN = unique(horzcat(H_SP_NN{:}));
NN_cor = H_SP_NN(~ismember(H_SP_NN, H_SP_new));
NN_inc = H_SP_NN(ismember(H_SP_NN, H_SP_new));

Avail_SP_List = true(1,length(NN_cor));
lbl_prop_lst = [];

% we will have no zero SP case
while all(~Avail_SP_List) == 0
    Avail_SP = NN_cor(Avail_SP_List);
    rand_idx = randi([1 length(Avail_SP)],1,1);
    Neigh_rand_idx = Al{Avail_SP(1,rand_idx),1};
    %Neigh_rand_idx = Neigh_rand_idx(~ismember(Neigh_rand_idx, Avail_SP));
    Neigh_rand_idx = Neigh_rand_idx(ismember(Neigh_rand_idx, NN_inc));
    for kk = 1:length(Neigh_rand_idx)
        % Identify the boundary between rand_idx and kk
        seg_img_temp = seg_img;
        seg_img_temp(seg_img == Avail_SP(1,rand_idx)) = Neigh_rand_idx(1,kk);
        mut_bound = edge(seg_img, 'canny') - edge(seg_img_temp, 'canny');
        
        % Compute how much line segment or edge strength is at this inersection
        if sum(sum(Im_E .* mut_bound)) <= thresh && ...
                sum(mut_bound(:))/sum(sum(seg_img == Neigh_rand_idx(1,kk))) >= thresh2
            if ~isempty(lbl_prop_lst) && sum(ismember(Avail_SP(1,rand_idx), lbl_prop_lst(:,1)))
                lbl_prop_lst = [lbl_prop_lst; ...
                    Neigh_rand_idx(1,kk) lbl_prop_lst(ismember(Avail_SP(1,rand_idx), ...
                    lbl_prop_lst(:,1)),2) sum(mut_bound(:))];
            else
                lbl_prop_lst = [lbl_prop_lst; ...
                    Neigh_rand_idx(1,kk) Avail_SP(1,rand_idx) sum(mut_bound(:))];
            end
            Avail_SP_List(1, NN_cor == Avail_SP(1, rand_idx)) = false;
            NN_cor = [NN_cor, Neigh_rand_idx(1,kk)];
            Avail_SP_List = [Avail_SP_List, true];
            NN_inc(NN_inc == Neigh_rand_idx(1,kk)) = [];
            % break;
        end
        
    end
    Avail_SP_List(1, NN_cor == Avail_SP(1, rand_idx)) = false;
end

for jj = 1:length(NN_inc)
    Neigh_jj = Al{NN_inc(1,jj),1};
    Neigh_jj = Neigh_jj(~ismember(Neigh_jj, NN_cor));
    for kk = 1:length(Neigh_jj)
        seg_img_temp = seg_img;
        seg_img_temp(seg_img == NN_inc(1,jj)) = Neigh_jj(1,kk);
        mut_bound = edge(seg_img, 'canny') - edge(seg_img_temp, 'canny');% can be optimized
        clear seg_img_temp;
        % Compute how much line segment or edge strength is at this
        % inersection
        if sum(sum(Im_E .* mut_bound)) <= thresh && ...
                sum(mut_bound(:))/sum(sum(seg_img == Neigh_jj(1,kk))) >= thresh2
            lbl_prop_lst = [lbl_prop_lst; ...
                Neigh_jj(1,kk) NN_inc(1,jj) sum(mut_bound(:))];
            NN_cor = [NN_cor, NN_inc(1,jj) , Neigh_jj(1,kk)];
            % break;
        end
    end
end
%
lbl_prop_lst;
seg_img2 = seg_img;
for jj = 1:size(lbl_prop_lst,1)
    seg_img2(seg_img == lbl_prop_lst(jj,1)) = lbl_prop_lst(jj,2);
end

end

