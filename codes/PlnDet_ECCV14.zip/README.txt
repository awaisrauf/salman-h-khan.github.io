Disclaimer: the author of the code or UWA are not responsible for any damages 
that may result from using this code.
Copyright (c) 2014 Salman Hameed Khan (UWA). All rights reserved.
salman.khan at research.uwa.edu.au

The main function file is PlnDet.m
An example image with the detected planar map can be found in the folder "Sample"

If you use this code please cite the related publication:

"Geometry Driven Semantic Labeling of Indoor Scenes." Khan, Salman Hameed, et al. 
Computer Vision–ECCV 2014. Springer International Publishing, 2014. 679-694.

The above copyright notice and this permission notice shall be included in 
all copies or substantial portions of the Software.