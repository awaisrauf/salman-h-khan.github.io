function [seg_img3] = plnSmthSP(Img, planeLbl)
% Further smoothing can be done on Super Pixels

seg_img3 = zeros(480,640);
cd('FelzenswalbSP/')
I_SP = test_igraphseg(Img);
for jj = 1: max(I_SP(:))
    seg_img3(I_SP == jj) = mode(planeLbl(I_SP == jj));
end
cd ..
end

