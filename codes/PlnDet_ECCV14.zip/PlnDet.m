function [planeLbl, smthPlaneLbl] = PlnDet(Img, Dmap, rDmap)
% -------------------------------------------------------------------------
% This function estimates rough geometry of indoor scenes by estimating
% planar regions. It operates on RGBD images and is robust to Kinect Depth
% map holes
% Inputs: 
%   - Img   : RGB Image (h x w x 3)
%   - Dmap  : Depth Image (h x w)
%   - rDmap : raw depth map (h x w)
% Outputs:
%   - planeLbl : a map of approximated planar regions with size h x w
%   - smthPlaneLbl : a smooth version of approximated planar regions
% Note: - The function uses the region adjacency code written by
%       Peter Kovesi (Centre for Exploration Targeting, UWA)
%       - This function estimates normals based on SVD. For this we use
%       the code from Silberman et al toolbox accompanying NYUv2 dataset.
%       Full reference is given in the related function: getNormals
% -------------------------------------------------------------------------
% Author: Salman Khan, School of CSSE, UWA
% Date: 24-12-2013
addpath('Normals/');
addpath('RegAdj/');
addpath('FelzenswalbSP/');

% Calculate normals and cluster them
[vs_normal, points3d] = getVSNormals(Dmap); % 0.070 sec
[seg_img] = getSPbyClustering(vs_normal, points3d, Img); % 1.739 sec

% Edge detector
[Im_E] = SmthEdge(Img);

% Select SP's whose majority of the portion lies in regions with holes
[H_SP_new] = holeSP(rDmap, seg_img);

% Find the Adjacency Matrix for all SP -- 0.61sec
[Al] = adjMat(seg_img);

% Find all unique neighbours of incorrect planes
[planeLbl] = unqNN(H_SP_new, Al, Im_E, seg_img);

% Further smoothing can be done on Super Pixels
[smthPlaneLbl] = plnSmthSP(Img, planeLbl);
end