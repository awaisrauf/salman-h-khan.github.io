%Author: Salman H. Khan
%Date: 22/04/2013
function [L] = test_igraphseg(I)
% K is the scale parameter, and a larger value indicates a preference for 
% larger regions
K = 50;%15;
% MIN is the minimum region size (pixels)
Min = 500;%200;

I = im2uint8(I); % Converts to a uint data class
[L,maxval] = igraphseg(I, K, Min); 
%Give a sequence wise number to each label
unique_labels = unique(L);

L_temp = zeros(size(L));
for i = 1:numel(unique_labels)
    L_temp(L == unique_labels(i)) = i;
end
L = L_temp;
end