function [vs_normal, points3d] = getVSNormals(imgDepth)

% Convert to 3D point
fx_rgb = 518.8579;  fy_rgb = 519.4696;
cx_rgb = 325.5824;  cy_rgb = 253.7362;

[xx0, yy0] = meshgrid(1:size(imgDepth, 2), 1:size(imgDepth, 1));

xx1 = (xx0 - cx_rgb) .* imgDepth / fx_rgb;
yy1 = (yy0 - cy_rgb) .* imgDepth / fy_rgb;
zz1 = imgDepth;

points3d = [xx1(:) -yy1(:) zz1(:)];

xx = reshape(points3d(:,1), size(imgDepth,1), size(imgDepth,2));
yy = reshape(points3d(:,2), size(imgDepth,1), size(imgDepth,2));
zz = reshape(points3d(:,3), size(imgDepth,1), size(imgDepth,2));

x = xx; y = yy; z = zz;
M = 15; % Filter size

ab = fspecial('sobel');
ba = ab';
ax = imfilter(x, ones(M,M), 'replicate');
ay = imfilter(y, ones(M,M), 'replicate');
az = imfilter(z, ones(M,M), 'replicate');
ax = imfilter(ax, ba, 'replicate');
ay = imfilter(ay, ba, 'replicate');
az = imfilter(az, ba, 'replicate');
aa = [ax(:), ay(:), az(:)];

bx = imfilter(x, ones(M,M), 'replicate');
by = imfilter(y, ones(M,M), 'replicate');
bz = imfilter(z, ones(M,M), 'replicate');
bx = imfilter(bx, ab, 'replicate');
by = imfilter(by, ab, 'replicate');
bz = imfilter(bz, ab, 'replicate');
bb = [bx(:), by(:), bz(:)];

rr = cross(aa, bb);
h = size(xx, 1);
w = size(xx, 2);
a = reshape(rr(:,1), h, w);
b = reshape(rr(:,2), h, w);
c = reshape(rr(:,3), h, w);
s = sqrt(a.*a + b.*b + c.*c + 1e-6);
a = a./s;
b = b./s;
c = c./s;

a = (a + 1)/2;
b = (b + 1)/2;
c = (c + 1)/2;

vs_normal = cat(3, a, b, c);
end