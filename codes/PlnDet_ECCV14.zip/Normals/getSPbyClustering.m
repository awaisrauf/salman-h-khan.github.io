function [seg_img] = getSPbyClustering(vs_normal, points3d, Im)

vs_normal = im2double(vs_normal);
a_1 = vs_normal(:,:,1);
b_1 = vs_normal(:,:,2);
c_1 = vs_normal(:,:,3);

xx = reshape(points3d(:,1), size(Im,1), size(Im,2));
yy = reshape(points3d(:,2), size(Im,1), size(Im,2));
zz = reshape(points3d(:,3), size(Im,1), size(Im,2));

Num_Clu = 6; % Number of Clusters

Im = im2double(Im);
a_2 = Im(:,:,1);
b_2 = Im(:,:,2);
c_2 = Im(:,:,3);

A = [a_1(:), b_1(:), c_1(:) 0.05*a_2(:) 0.05*b_2(:) 0.05*c_2(:)];

[cid, ctr] = kmeans(A, Num_Clu); 
ids = reshape(cid, size(Im,1), size(Im,2));
total = 0;
map = zeros(size(ids));

for n = 1 : Num_Clu
    im = (ids == n);
    L = bwlabel(im, 4);
    map(L > 0) = L(L > 0) + total;
    total = total + max(L(:));
end

mask = zeros(size(Im,1), size(Im,2));
mask(:,:) = 1;
mask = ~mask;
map(mask) = 0;

N = max(map(:));
z = [];
num = 1;
seg_img = zeros(size(map));
for n = 1 : N
    if sum(sum(map == n)) >= 500
        seg_img(map == n) = num;
        num = num + 1;
    end
end

end